// /api/scores.js
// Vercel Serverless Function: lấy dữ liệu từ Google Sheet, cache lại để
// hàng nghìn người dùng cùng lúc không gọi trực tiếp Google.

const SHEET_ID = "1sdUo3LSKAk82Sqo8jZsmUeqZ2SDWyOofbRkJRiM20hE";
const SHEET_NAME = "Sheet1";
const GVIZ_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tjs=1&sheet=${encodeURIComponent(SHEET_NAME)}`;

export default async function handler(req, res) {
  try {
    const r = await fetch(GVIZ_URL);
    if (!r.ok) {
      res.status(502).json({ error: 'Không tải được Google Sheet', status: r.status });
      return;
    }
    const text = await r.text();
    const jsonStr = text.substring(text.indexOf('(') + 1, text.lastIndexOf(')'));
    const json = JSON.parse(jsonStr);

    const cols = json.table.cols.map(c => (c.label || '').trim());
    const rows = json.table.rows;

    const idx = {
      ma:   cols.findIndex(c => /ma\s*d?inh\s*danh/i.test(c) || /mã\s*định\s*danh/i.test(c)),
      ten:  cols.findIndex(c => /ho\s*va\s*ten/i.test(c) || /họ\s*và\s*tên/i.test(c)),
      toan: cols.findIndex(c => /toan|toán/i.test(c)),
      tv:   cols.findIndex(c => /tv|tiếng\s*việt|tieng\s*viet/i.test(c)),
      anh:  cols.findIndex(c => /anh/i.test(c) && /tieng|tiếng/i.test(c)),
      tong: cols.findIndex(c => /tong|tổng/i.test(c)),
    };

    const data = {};
    rows.forEach(r => {
      const cells = r.c || [];
      const get = (i) => (i >= 0 && cells[i]) ? cells[i].v : null;
      const maVal = get(idx.ma);
      if (maVal === null || maVal === undefined || maVal === '') return;
      const maStr = String(maVal).trim();
      data[maStr] = {
        ten:  get(idx.ten),
        toan: get(idx.toan),
        tv:   get(idx.tv),
        anh:  get(idx.anh),
        tong: get(idx.tong),
      };
    });

    // Cache ở CDN Vercel 10 phút, vẫn phục vụ bản cũ 1h nếu Google lỗi/chậm
    res.setHeader('Cache-Control', 's-maxage=600, stale-while-revalidate=3600');
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: 'Lỗi server', message: String(err) });
  }
}
